﻿CREATE PROCEDURE [dbo].SearchCRIME_SP
	@C_ID int
AS
	SELECT  c.C_TYPE,c.C_DATE,c.LOCATION,c.C_ID
	from CRIME c
	where c.C_ID = @C_ID
RETURN 0