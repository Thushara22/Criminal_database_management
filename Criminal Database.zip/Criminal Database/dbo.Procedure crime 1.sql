﻿CREATE PROCEDURE [dbo].CRIMEADD_SP
	@C_TYPE varchar(25),
	@C_DATE date,
	@LOCATION varchar(25),
	@C_ID int
AS
	insert into CRIME(C_TYPE,C_DATE,LOCATION,C_ID) values(@C_TYPE,@C_DATE,@LOCATION,@C_ID)
RETURN 0
