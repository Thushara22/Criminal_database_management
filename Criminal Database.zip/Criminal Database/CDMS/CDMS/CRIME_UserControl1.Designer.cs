﻿
namespace CDMS
{
    partial class CRIME_UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.C_ID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.C_IDtextBox1 = new System.Windows.Forms.TextBox();
            this.C_TYPEtextBox2 = new System.Windows.Forms.TextBox();
            this.C_DATEtextBox3 = new System.Windows.Forms.TextBox();
            this.LOCATIONtextBox4 = new System.Windows.Forms.TextBox();
            this.CRIMEClearbutton4 = new System.Windows.Forms.Button();
            this.DELETECrimebutton3 = new System.Windows.Forms.Button();
            this.SEARCHCRIMEbutton2 = new System.Windows.Forms.Button();
            this.ADDCrimebutton1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // C_ID
            // 
            this.C_ID.AutoSize = true;
            this.C_ID.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C_ID.Location = new System.Drawing.Point(295, 24);
            this.C_ID.Name = "C_ID";
            this.C_ID.Size = new System.Drawing.Size(63, 27);
            this.C_ID.TabIndex = 0;
            this.C_ID.Text = "C_ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(311, 613);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "LOCATION:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(552, 520);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "C_DATE:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(70, 520);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 27);
            this.label3.TabIndex = 3;
            this.label3.Text = "C_TYPE:";
            // 
            // C_IDtextBox1
            // 
            this.C_IDtextBox1.BackColor = System.Drawing.Color.Black;
            this.C_IDtextBox1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C_IDtextBox1.ForeColor = System.Drawing.Color.White;
            this.C_IDtextBox1.Location = new System.Drawing.Point(387, 24);
            this.C_IDtextBox1.Name = "C_IDtextBox1";
            this.C_IDtextBox1.Size = new System.Drawing.Size(158, 30);
            this.C_IDtextBox1.TabIndex = 4;
            // 
            // C_TYPEtextBox2
            // 
            this.C_TYPEtextBox2.BackColor = System.Drawing.Color.Black;
            this.C_TYPEtextBox2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C_TYPEtextBox2.ForeColor = System.Drawing.Color.White;
            this.C_TYPEtextBox2.Location = new System.Drawing.Point(166, 517);
            this.C_TYPEtextBox2.Name = "C_TYPEtextBox2";
            this.C_TYPEtextBox2.Size = new System.Drawing.Size(171, 30);
            this.C_TYPEtextBox2.TabIndex = 5;
            // 
            // C_DATEtextBox3
            // 
            this.C_DATEtextBox3.BackColor = System.Drawing.Color.Black;
            this.C_DATEtextBox3.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C_DATEtextBox3.ForeColor = System.Drawing.Color.White;
            this.C_DATEtextBox3.Location = new System.Drawing.Point(690, 517);
            this.C_DATEtextBox3.Name = "C_DATEtextBox3";
            this.C_DATEtextBox3.Size = new System.Drawing.Size(158, 30);
            this.C_DATEtextBox3.TabIndex = 6;
            // 
            // LOCATIONtextBox4
            // 
            this.LOCATIONtextBox4.BackColor = System.Drawing.Color.Black;
            this.LOCATIONtextBox4.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOCATIONtextBox4.ForeColor = System.Drawing.Color.White;
            this.LOCATIONtextBox4.Location = new System.Drawing.Point(453, 613);
            this.LOCATIONtextBox4.Name = "LOCATIONtextBox4";
            this.LOCATIONtextBox4.Size = new System.Drawing.Size(158, 30);
            this.LOCATIONtextBox4.TabIndex = 7;
            // 
            // CRIMEClearbutton4
            // 
            this.CRIMEClearbutton4.BackColor = System.Drawing.Color.White;
            this.CRIMEClearbutton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CRIMEClearbutton4.Image = global::CDMS.Properties.Resources.clear1;
            this.CRIMEClearbutton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CRIMEClearbutton4.Location = new System.Drawing.Point(715, 425);
            this.CRIMEClearbutton4.Name = "CRIMEClearbutton4";
            this.CRIMEClearbutton4.Size = new System.Drawing.Size(159, 54);
            this.CRIMEClearbutton4.TabIndex = 11;
            this.CRIMEClearbutton4.Text = "CLEAR";
            this.CRIMEClearbutton4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CRIMEClearbutton4.UseVisualStyleBackColor = false;
            this.CRIMEClearbutton4.Click += new System.EventHandler(this.CRIMEClearbutton4_Click);
            // 
            // DELETECrimebutton3
            // 
            this.DELETECrimebutton3.BackColor = System.Drawing.Color.White;
            this.DELETECrimebutton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DELETECrimebutton3.Image = global::CDMS.Properties.Resources.delete1;
            this.DELETECrimebutton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DELETECrimebutton3.Location = new System.Drawing.Point(482, 425);
            this.DELETECrimebutton3.Name = "DELETECrimebutton3";
            this.DELETECrimebutton3.Size = new System.Drawing.Size(188, 54);
            this.DELETECrimebutton3.TabIndex = 10;
            this.DELETECrimebutton3.Text = "DELETE";
            this.DELETECrimebutton3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DELETECrimebutton3.UseVisualStyleBackColor = false;
            this.DELETECrimebutton3.Click += new System.EventHandler(this.DELETECrimebutton3_Click);
            // 
            // SEARCHCRIMEbutton2
            // 
            this.SEARCHCRIMEbutton2.BackColor = System.Drawing.Color.White;
            this.SEARCHCRIMEbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SEARCHCRIMEbutton2.Image = global::CDMS.Properties.Resources.search1;
            this.SEARCHCRIMEbutton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SEARCHCRIMEbutton2.Location = new System.Drawing.Point(256, 425);
            this.SEARCHCRIMEbutton2.Name = "SEARCHCRIMEbutton2";
            this.SEARCHCRIMEbutton2.Size = new System.Drawing.Size(181, 54);
            this.SEARCHCRIMEbutton2.TabIndex = 9;
            this.SEARCHCRIMEbutton2.Text = "SEARCH";
            this.SEARCHCRIMEbutton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SEARCHCRIMEbutton2.UseVisualStyleBackColor = false;
            this.SEARCHCRIMEbutton2.Click += new System.EventHandler(this.SEARCHCRIMEbutton2_Click);
            // 
            // ADDCrimebutton1
            // 
            this.ADDCrimebutton1.BackColor = System.Drawing.Color.White;
            this.ADDCrimebutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ADDCrimebutton1.Image = global::CDMS.Properties.Resources.download1;
            this.ADDCrimebutton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ADDCrimebutton1.Location = new System.Drawing.Point(66, 425);
            this.ADDCrimebutton1.Name = "ADDCrimebutton1";
            this.ADDCrimebutton1.Size = new System.Drawing.Size(148, 54);
            this.ADDCrimebutton1.TabIndex = 8;
            this.ADDCrimebutton1.Text = "ADD";
            this.ADDCrimebutton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ADDCrimebutton1.UseVisualStyleBackColor = false;
            this.ADDCrimebutton1.Click += new System.EventHandler(this.ADDCrimebutton1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 96);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(902, 303);
            this.dataGridView1.TabIndex = 12;
            // 
            // CRIME_UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.CRIMEClearbutton4);
            this.Controls.Add(this.DELETECrimebutton3);
            this.Controls.Add(this.SEARCHCRIMEbutton2);
            this.Controls.Add(this.ADDCrimebutton1);
            this.Controls.Add(this.LOCATIONtextBox4);
            this.Controls.Add(this.C_DATEtextBox3);
            this.Controls.Add(this.C_TYPEtextBox2);
            this.Controls.Add(this.C_IDtextBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.C_ID);
            this.Name = "CRIME_UserControl1";
            this.Size = new System.Drawing.Size(938, 716);
            this.Load += new System.EventHandler(this.CRIME_UserControl1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label C_ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox C_IDtextBox1;
        private System.Windows.Forms.TextBox C_TYPEtextBox2;
        private System.Windows.Forms.TextBox C_DATEtextBox3;
        private System.Windows.Forms.TextBox LOCATIONtextBox4;
        private System.Windows.Forms.Button ADDCrimebutton1;
        private System.Windows.Forms.Button SEARCHCRIMEbutton2;
        private System.Windows.Forms.Button DELETECrimebutton3;
        private System.Windows.Forms.Button CRIMEClearbutton4;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}
