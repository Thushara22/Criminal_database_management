﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CDMS
{
   public partial class JAIL_UserControl1 : UserControl
    {
        private static JAIL_UserControl1 _instance;

        public static JAIL_UserControl1 Instane
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new JAIL_UserControl1();
                }
                return _instance;
            }
        }
        public JAIL_UserControl1()
        {
            InitializeComponent();
        }


        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");

        public void refresh_DataGridView()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAllJAILData_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<INVALID SQL OPERATIOON>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];
                this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }





        private void ADDJAILbutton1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("JAILAdd_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@JAIL_ID", JAIL_IDtextBox1.Text);
            cmd.Parameters.AddWithValue("@J_NAME", J_NAMEtextBox2.Text);
            cmd.Parameters.AddWithValue("@DURATION", DURATION_textBox3.Text);
            cmd.Parameters.AddWithValue("@C_ID", C_IDtextBox4.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("               <<<INVAILD SQL OPERATION>>>: \n" + ex);
            }
            con.Close();
            refresh_DataGridView();
        }

        private void JAIL_UserControl1_Load(object sender, EventArgs e)
        {
            refresh_DataGridView();
        }

        private void DELTEbutton2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("DeleteJAIL_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@C_ID", C_IDtextBox4.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("          <<<INVAILD SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                refresh_DataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            
          
            
               
            
        }

        private void SEARCHJAILbutton3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SearchJAIL_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@C_ID", C_IDtextBox4.Text);

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<INVALID SQL OPERATIOON>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];
                this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;


            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        private void CLEARJAILbutton4_Click(object sender, EventArgs e)
        {
            C_IDtextBox4.Text = "";
            JAIL_IDtextBox1.Text = "";
            J_NAMEtextBox2.Text = "";
            DURATION_textBox3.Text = "";
        }
    }
}
