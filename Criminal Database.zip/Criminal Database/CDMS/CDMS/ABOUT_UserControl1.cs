﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CDMS
{
    public partial class ABOUT_UserControl1 : UserControl
    {
        private static ABOUT_UserControl1 _instance;

        public static ABOUT_UserControl1 Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new ABOUT_UserControl1();
                }
                return _instance;
            }
        }
        public ABOUT_UserControl1()
        {
            InitializeComponent();
        }

        private void ABOUT_UserControl1_Load(object sender, EventArgs e)
        {

        }
    }
}
