﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CDMS
{
    public partial class SETTINGS_UserControl1 : UserControl
    {
        private static SETTINGS_UserControl1 _instance;

        public static SETTINGS_UserControl1 Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new SETTINGS_UserControl1();
                }
                return _instance;
            }
        }
        public SETTINGS_UserControl1()
        {
            InitializeComponent();
        }
    }
}
