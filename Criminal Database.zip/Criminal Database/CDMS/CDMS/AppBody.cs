﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CDMS
{
    public partial class AppBody : Form
    {
        public AppBody()
        {
            InitializeComponent();

            //initialization for sliding pannel
            isSlidingPannelExpanded = true;
            expandSlidingPannelGuI();

        }

        private void AppBody_Load(object sender, EventArgs e)
        {
            this.Opacity = 0.1;
            Log_in_Timer.Start();
        }
        
        private void Log_in_Timer_Tick(object sender, EventArgs e)
        {
            if(this.Opacity<=1.0)
            {
                this.Opacity += 0.025;
            }
            else
            {
                Log_in_Timer.Stop();
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void MinimizeButton_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void LogOffButton_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            this.Hide();
            obj.Show();
        }


        public void expandSlidingPannelGuI()
        {
            //gui adjustment for expanding
            CriminalTabButton.Text = "CRIMINAL";
            CrimeTabButton.Text = "CRIME";
            JailTabButton.Text = "JAIL";
            JudgeTabButton.Text = "JUDGE";
           
            AboutTabButton.Text = "ABOUT";
            SlidingPannel_ToggelButton.Image = Properties.Resources.LEFT_Arrows_20_;
            CriminalTabButton.Image = null;
            CrimeTabButton.Image = null;
            JailTabButton.Image = null;
            JudgeTabButton.Image = null;
           
            AboutTabButton.Image = null;

        }

        public void retractSlidingPannelGUI()
        {
            //gui adjustment for expanding
            CriminalTabButton.Text = "";
            CrimeTabButton.Text = "";
            JailTabButton.Text = "";
            JudgeTabButton.Text = "";
            
            AboutTabButton.Text = "";
            SlidingPannel_ToggelButton.Image = Properties.Resources.RIGHT_Arrows_12_;
            CriminalTabButton.Image = Properties.Resources.criminal_6_;
            CrimeTabButton.Image = Properties.Resources.Crime____;
            JailTabButton.Image = Properties.Resources.jail_6_;
            JudgeTabButton.Image = Properties.Resources.Judge_3_;
           
            AboutTabButton.Image = Properties.Resources.ADMIN_LOGIN;

        }


        //Sliding Pannel Code starts from here
        bool isSlidingPannelExpanded;
        const int MaxSlidderWidth=300;
        const int MinSlidderWidth=100;

        private void SlidingPannel_ToggelButton_Click(object sender, EventArgs e)
        {
            if(isSlidingPannelExpanded)
            {
                //retractSlidingPannelGUI();
            }
            SlidingPannel_Timer.Start();
        }

        private void SlidingPannel_Timer_Tick(object sender, EventArgs e)
        {
            if(isSlidingPannelExpanded)
            {
                //retract pannel
                SlidingPannel.Width -= 30;
                if(SlidingPannel.Width <= MinSlidderWidth)
                {
                    //stop retract
                    isSlidingPannelExpanded = false;
                    SlidingPannel_Timer.Stop();
                    retractSlidingPannelGUI();
                    this.Refresh();
                }
            }
            else
            {
                ////expand the pannel
                SlidingPannel.Width += 30;
                if (SlidingPannel.Width >= MaxSlidderWidth)
                {
                    //stop expanding
                    isSlidingPannelExpanded = true;
                    SlidingPannel_Timer.Stop();
                    expandSlidingPannelGuI();
                    this.Refresh();
                }

            }

            
            
            
            
                
                
                

                
            
        }

        private void CriminalTabButton_Click(object sender, EventArgs e)
        {
            if(! ContentPannel.Controls.Contains(CRIMINAL_UserControl1.Instance))
            {
                ContentPannel.Controls.Add(CRIMINAL_UserControl1.Instance);
                CRIMINAL_UserControl1.Instance.Dock = DockStyle.Fill;
                CRIMINAL_UserControl1.Instance.BringToFront();
            }
            else
            {
                CRIMINAL_UserControl1.Instance.BringToFront();
            }
        }

        private void CrimeTabButton_Click(object sender, EventArgs e)
        {
            if(! ContentPannel.Controls.Contains(CRIME_UserControl1.Instance))
            {
                ContentPannel.Controls.Add(CRIME_UserControl1.Instance);
                CRIME_UserControl1.Instance.Dock = DockStyle.Fill;
                CRIME_UserControl1.Instance.BringToFront();
            }
            else
            {
                CRIME_UserControl1.Instance.BringToFront();
            }
        }

        private void JailTabButton_Click(object sender, EventArgs e)
        {
            if(! ContentPannel.Controls.Contains(JAIL_UserControl1.Instane))
            {
                ContentPannel.Controls.Add(JAIL_UserControl1.Instane);
                JAIL_UserControl1.Instane.Dock = DockStyle.Fill;
                JAIL_UserControl1.Instane.BringToFront();
                
            }
            else
            {
                JAIL_UserControl1.Instane.BringToFront();
            }
        }

        private void JudgeTabButton_Click(object sender, EventArgs e)
        {
            if(! ContentPannel.Controls.Contains(JUDGE_UserControl1.Instance))
            {
                ContentPannel.Controls.Add(JUDGE_UserControl1.Instance);
                JUDGE_UserControl1.Instance.Dock = DockStyle.Fill;
                JUDGE_UserControl1.Instance.BringToFront();
            }
            else
            {
                JUDGE_UserControl1.Instance.BringToFront();
            }
        }

        private void SettingsTabButton_Click(object sender, EventArgs e)
        {
            if(! ContentPannel.Controls.Contains(SETTINGS_UserControl1.Instance))
            {
                ContentPannel.Controls.Add(SETTINGS_UserControl1.Instance);
                SETTINGS_UserControl1.Instance.Dock = DockStyle.Fill;
                SETTINGS_UserControl1.Instance.BringToFront();
            }
            else
            {
                SETTINGS_UserControl1.Instance.BringToFront();
            }
        }

        private void AboutTabButton_Click(object sender, EventArgs e)
        {
            if(! ContentPannel.Controls.Contains(ABOUT_UserControl1.Instance))
            {
                ContentPannel.Controls.Add(ABOUT_UserControl1.Instance);
                ABOUT_UserControl1.Instance.Dock = DockStyle.Fill;
                ABOUT_UserControl1.Instance.BringToFront();
            }
            else
            {
                ABOUT_UserControl1.Instance.BringToFront();
            }
        }
    }
}
