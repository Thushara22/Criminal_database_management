﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CDMS
{
    public partial class CRIMINAL_UserControl1 : UserControl
    {
        private  static CRIMINAL_UserControl1 _instance;

        public static CRIMINAL_UserControl1 Instance
        {
          get
          {
                if(_instance == null)
                {
                    _instance = new CRIMINAL_UserControl1();
                }
                return _instance;
          
          }       

        }
        public CRIMINAL_UserControl1()
        {
            InitializeComponent();
        }



        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");


        private void CRIMINAL_UserControl1_Load(object sender, EventArgs e)
        {
            refresh_DataGridView();
        }

        public void refresh_DataGridView()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAllCRIMINALData_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<INVALID SQL OPERATIOON>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];
                
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("CRIMINALAdd_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@C_ID",C_IDTextBox.Text);
            cmd.Parameters.AddWithValue("@DOB", dobtextBox1.Text);
            cmd.Parameters.AddWithValue("@FNAME",FNameTextBox.Text);
            cmd.Parameters.AddWithValue("@LNAME",LNameTextBox.Text);
            cmd.Parameters.AddWithValue("@PHONE",PhoneNoTextBox.Text);
            cmd.Parameters.AddWithValue("@ADDRESS",AddressTextBox.Text);
            cmd.Parameters.AddWithValue("@STATUS",StatusTextBox.Text);
            
            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("                    <<<INVALID SQL OPERATION:\n" + ex);
            }
            con.Close();
            refresh_DataGridView();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("CriminalDelete_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@C_ID", C_IDTextBox.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("            <<<INVAILD SQL OPERATON>>> \n" + ex);
                }
                con.Close();

                refresh_DataGridView();
            }
             catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                SqlCommand cmd = new SqlCommand("SearchCriminal_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@C_ID",C_IDTextBox.Text);

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<INVALID SQL OPERATIOON>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];


            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            C_IDTextBox.Text = "";
            FNameTextBox.Text = "";
            LNameTextBox.Text = "";
            StatusTextBox.Text = "";
            dobtextBox1.Text = "";
            PhoneNoTextBox.Text = "";
            AddressTextBox.Text = "";
        }
        

        
    }
    
}
