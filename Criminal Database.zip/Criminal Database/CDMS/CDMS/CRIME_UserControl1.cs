﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CDMS
{
    public partial class CRIME_UserControl1 : UserControl
    {
        private static CRIME_UserControl1 _instance;

        public static CRIME_UserControl1 Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new CRIME_UserControl1();
                }
                return _instance;
            }

        }

        public CRIME_UserControl1()
        {
            InitializeComponent();
        }



        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");









        public void refresh_DataGridView()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAllCRIMEData_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<INVALID SQL OPERATIOON>>>: \n" + ex);
                }
                con.Close();


                dataGridView1.DataSource = DS.Tables[0];
                this.dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                this.dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                this.dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }


        private void ADDCrimebutton1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("CRIMEADD_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@C_TYPE", C_TYPEtextBox2.Text);
            cmd.Parameters.AddWithValue("@C_DATE", C_DATEtextBox3.Text);
            cmd.Parameters.AddWithValue("@LOCATION", LOCATIONtextBox4.Text);
            cmd.Parameters.AddWithValue("@C_ID", C_IDtextBox1.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("            <<<INVALID SQL OPERATION >>>:\n" + ex);
            }
            con.Close();

            refresh_DataGridView();
        }

        private void CRIME_UserControl1_Load(object sender, EventArgs e)
        {
            refresh_DataGridView();
        }

        private void DELETECrimebutton3_Click(object sender, EventArgs e)
        {
          try
          {
                SqlCommand cmd = new SqlCommand("CRIMEDelete_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@C_ID", C_IDtextBox1.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("           <<<INVAILD SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                refresh_DataGridView();   
          }     
          catch (Exception ex)
          {
                MessageBox.Show("" + ex);
          }
                                       
        }

        private void SEARCHCRIMEbutton2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SearchCRIME_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@C_ID", C_IDtextBox1.Text);

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);



                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("        <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                dataGridView1.DataSource = DS.Tables[0];

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        private void CRIMEClearbutton4_Click(object sender, EventArgs e)
        {
            C_IDtextBox1.Text = "";
            C_TYPEtextBox2.Text = "";
            C_DATEtextBox3.Text = "";
            LOCATIONtextBox4.Text = "";
        }
    }
}
