﻿
namespace CDMS
{
    partial class JAIL_UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CLEARJAILbutton4 = new System.Windows.Forms.Button();
            this.SEARCHJAILbutton3 = new System.Windows.Forms.Button();
            this.DELTEbutton2 = new System.Windows.Forms.Button();
            this.ADDJAILbutton1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.JAIL_IDtextBox1 = new System.Windows.Forms.TextBox();
            this.J_NAMEtextBox2 = new System.Windows.Forms.TextBox();
            this.DURATION_textBox3 = new System.Windows.Forms.TextBox();
            this.C_IDtextBox4 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // CLEARJAILbutton4
            // 
            this.CLEARJAILbutton4.BackColor = System.Drawing.Color.White;
            this.CLEARJAILbutton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CLEARJAILbutton4.Image = global::CDMS.Properties.Resources.clear2;
            this.CLEARJAILbutton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CLEARJAILbutton4.Location = new System.Drawing.Point(715, 334);
            this.CLEARJAILbutton4.Name = "CLEARJAILbutton4";
            this.CLEARJAILbutton4.Size = new System.Drawing.Size(199, 65);
            this.CLEARJAILbutton4.TabIndex = 3;
            this.CLEARJAILbutton4.Text = "CLEAR";
            this.CLEARJAILbutton4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CLEARJAILbutton4.UseVisualStyleBackColor = false;
            this.CLEARJAILbutton4.Click += new System.EventHandler(this.CLEARJAILbutton4_Click);
            // 
            // SEARCHJAILbutton3
            // 
            this.SEARCHJAILbutton3.BackColor = System.Drawing.Color.White;
            this.SEARCHJAILbutton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SEARCHJAILbutton3.Image = global::CDMS.Properties.Resources.search2;
            this.SEARCHJAILbutton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SEARCHJAILbutton3.Location = new System.Drawing.Point(249, 334);
            this.SEARCHJAILbutton3.Name = "SEARCHJAILbutton3";
            this.SEARCHJAILbutton3.Size = new System.Drawing.Size(213, 65);
            this.SEARCHJAILbutton3.TabIndex = 2;
            this.SEARCHJAILbutton3.Text = "SEARCH";
            this.SEARCHJAILbutton3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SEARCHJAILbutton3.UseVisualStyleBackColor = false;
            this.SEARCHJAILbutton3.Click += new System.EventHandler(this.SEARCHJAILbutton3_Click);
            // 
            // DELTEbutton2
            // 
            this.DELTEbutton2.BackColor = System.Drawing.Color.White;
            this.DELTEbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DELTEbutton2.Image = global::CDMS.Properties.Resources.delete2;
            this.DELTEbutton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DELTEbutton2.Location = new System.Drawing.Point(489, 334);
            this.DELTEbutton2.Name = "DELTEbutton2";
            this.DELTEbutton2.Size = new System.Drawing.Size(209, 65);
            this.DELTEbutton2.TabIndex = 1;
            this.DELTEbutton2.Text = "DELETE";
            this.DELTEbutton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DELTEbutton2.UseVisualStyleBackColor = false;
            this.DELTEbutton2.Click += new System.EventHandler(this.DELTEbutton2_Click);
            // 
            // ADDJAILbutton1
            // 
            this.ADDJAILbutton1.BackColor = System.Drawing.Color.White;
            this.ADDJAILbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ADDJAILbutton1.Image = global::CDMS.Properties.Resources.download2;
            this.ADDJAILbutton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ADDJAILbutton1.Location = new System.Drawing.Point(18, 334);
            this.ADDJAILbutton1.Name = "ADDJAILbutton1";
            this.ADDJAILbutton1.Size = new System.Drawing.Size(192, 65);
            this.ADDJAILbutton1.TabIndex = 0;
            this.ADDJAILbutton1.Text = "ADD NEW";
            this.ADDJAILbutton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ADDJAILbutton1.UseVisualStyleBackColor = false;
            this.ADDJAILbutton1.Click += new System.EventHandler(this.ADDJAILbutton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(111, 483);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 27);
            this.label1.TabIndex = 4;
            this.label1.Text = "JAIL_ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(294, 604);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 27);
            this.label2.TabIndex = 5;
            this.label2.Text = "J_NAME:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(511, 482);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 27);
            this.label3.TabIndex = 6;
            this.label3.Text = "DURATION:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(366, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 27);
            this.label4.TabIndex = 7;
            this.label4.Text = "C_ID:";
            // 
            // JAIL_IDtextBox1
            // 
            this.JAIL_IDtextBox1.BackColor = System.Drawing.Color.Black;
            this.JAIL_IDtextBox1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JAIL_IDtextBox1.ForeColor = System.Drawing.Color.White;
            this.JAIL_IDtextBox1.Location = new System.Drawing.Point(232, 481);
            this.JAIL_IDtextBox1.Name = "JAIL_IDtextBox1";
            this.JAIL_IDtextBox1.Size = new System.Drawing.Size(169, 30);
            this.JAIL_IDtextBox1.TabIndex = 8;
            // 
            // J_NAMEtextBox2
            // 
            this.J_NAMEtextBox2.BackColor = System.Drawing.Color.Black;
            this.J_NAMEtextBox2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J_NAMEtextBox2.ForeColor = System.Drawing.Color.White;
            this.J_NAMEtextBox2.Location = new System.Drawing.Point(438, 604);
            this.J_NAMEtextBox2.Name = "J_NAMEtextBox2";
            this.J_NAMEtextBox2.Size = new System.Drawing.Size(169, 30);
            this.J_NAMEtextBox2.TabIndex = 9;
            // 
            // DURATION_textBox3
            // 
            this.DURATION_textBox3.BackColor = System.Drawing.Color.Black;
            this.DURATION_textBox3.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DURATION_textBox3.ForeColor = System.Drawing.Color.White;
            this.DURATION_textBox3.Location = new System.Drawing.Point(672, 480);
            this.DURATION_textBox3.Name = "DURATION_textBox3";
            this.DURATION_textBox3.Size = new System.Drawing.Size(169, 30);
            this.DURATION_textBox3.TabIndex = 10;
            // 
            // C_IDtextBox4
            // 
            this.C_IDtextBox4.BackColor = System.Drawing.Color.Black;
            this.C_IDtextBox4.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C_IDtextBox4.ForeColor = System.Drawing.Color.White;
            this.C_IDtextBox4.Location = new System.Drawing.Point(474, 30);
            this.C_IDtextBox4.Name = "C_IDtextBox4";
            this.C_IDtextBox4.Size = new System.Drawing.Size(169, 30);
            this.C_IDtextBox4.TabIndex = 11;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 83);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(932, 231);
            this.dataGridView1.TabIndex = 12;
            // 
            // JAIL_UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.C_IDtextBox4);
            this.Controls.Add(this.DURATION_textBox3);
            this.Controls.Add(this.J_NAMEtextBox2);
            this.Controls.Add(this.JAIL_IDtextBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CLEARJAILbutton4);
            this.Controls.Add(this.SEARCHJAILbutton3);
            this.Controls.Add(this.DELTEbutton2);
            this.Controls.Add(this.ADDJAILbutton1);
            this.Name = "JAIL_UserControl1";
            this.Size = new System.Drawing.Size(938, 716);
            this.Load += new System.EventHandler(this.JAIL_UserControl1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ADDJAILbutton1;
        private System.Windows.Forms.Button DELTEbutton2;
        private System.Windows.Forms.Button SEARCHJAILbutton3;
        private System.Windows.Forms.Button CLEARJAILbutton4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox JAIL_IDtextBox1;
        private System.Windows.Forms.TextBox J_NAMEtextBox2;
        private System.Windows.Forms.TextBox DURATION_textBox3;
        private System.Windows.Forms.TextBox C_IDtextBox4;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}
