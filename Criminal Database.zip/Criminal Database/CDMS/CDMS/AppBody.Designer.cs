﻿
namespace CDMS
{
    partial class AppBody
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AppBody));
            this.Log_in_Timer = new System.Windows.Forms.Timer(this.components);
            this.SlidingPannel_Timer = new System.Windows.Forms.Timer(this.components);
            this.ContentPannel = new System.Windows.Forms.Panel();
            this.SlidingPannel = new System.Windows.Forms.Panel();
            this.CriminalTabButton = new System.Windows.Forms.Button();
            this.CrimeTabButton = new System.Windows.Forms.Button();
            this.JailTabButton = new System.Windows.Forms.Button();
            this.AboutTabButton = new System.Windows.Forms.Button();
            this.JudgeTabButton = new System.Windows.Forms.Button();
            this.SlidingPannel_ToggelButton = new System.Windows.Forms.Button();
            this.TitleBarPannel = new System.Windows.Forms.Panel();
            this.LogOffButton = new System.Windows.Forms.Button();
            this.MinimizeButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.SlidingPannel.SuspendLayout();
            this.TitleBarPannel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Log_in_Timer
            // 
            this.Log_in_Timer.Interval = 50;
            this.Log_in_Timer.Tick += new System.EventHandler(this.Log_in_Timer_Tick);
            // 
            // SlidingPannel_Timer
            // 
            this.SlidingPannel_Timer.Interval = 10;
            this.SlidingPannel_Timer.Tick += new System.EventHandler(this.SlidingPannel_Timer_Tick);
            // 
            // ContentPannel
            // 
            this.ContentPannel.BackColor = System.Drawing.Color.White;
            this.ContentPannel.Dock = System.Windows.Forms.DockStyle.Right;
            this.ContentPannel.Location = new System.Drawing.Point(306, 55);
            this.ContentPannel.Name = "ContentPannel";
            this.ContentPannel.Size = new System.Drawing.Size(938, 716);
            this.ContentPannel.TabIndex = 2;
            // 
            // SlidingPannel
            // 
            this.SlidingPannel.BackColor = System.Drawing.Color.White;
            this.SlidingPannel.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_2;
            this.SlidingPannel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SlidingPannel.Controls.Add(this.CriminalTabButton);
            this.SlidingPannel.Controls.Add(this.CrimeTabButton);
            this.SlidingPannel.Controls.Add(this.JailTabButton);
            this.SlidingPannel.Controls.Add(this.AboutTabButton);
            this.SlidingPannel.Controls.Add(this.JudgeTabButton);
            this.SlidingPannel.Controls.Add(this.SlidingPannel_ToggelButton);
            this.SlidingPannel.Dock = System.Windows.Forms.DockStyle.Left;
            this.SlidingPannel.Location = new System.Drawing.Point(0, 55);
            this.SlidingPannel.Name = "SlidingPannel";
            this.SlidingPannel.Size = new System.Drawing.Size(300, 716);
            this.SlidingPannel.TabIndex = 1;
            // 
            // CriminalTabButton
            // 
            this.CriminalTabButton.BackColor = System.Drawing.Color.Transparent;
            this.CriminalTabButton.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_22;
            this.CriminalTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CriminalTabButton.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CriminalTabButton.ForeColor = System.Drawing.Color.White;
            this.CriminalTabButton.Image = global::CDMS.Properties.Resources.criminal_6_;
            this.CriminalTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CriminalTabButton.Location = new System.Drawing.Point(0, 64);
            this.CriminalTabButton.Name = "CriminalTabButton";
            this.CriminalTabButton.Size = new System.Drawing.Size(297, 74);
            this.CriminalTabButton.TabIndex = 8;
            this.CriminalTabButton.Text = "CRIMINAL";
            this.CriminalTabButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CriminalTabButton.UseVisualStyleBackColor = false;
            this.CriminalTabButton.Click += new System.EventHandler(this.CriminalTabButton_Click);
            // 
            // CrimeTabButton
            // 
            this.CrimeTabButton.BackColor = System.Drawing.Color.Transparent;
            this.CrimeTabButton.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_2;
            this.CrimeTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CrimeTabButton.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CrimeTabButton.ForeColor = System.Drawing.Color.White;
            this.CrimeTabButton.Image = global::CDMS.Properties.Resources.Crime____;
            this.CrimeTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CrimeTabButton.Location = new System.Drawing.Point(3, 144);
            this.CrimeTabButton.Name = "CrimeTabButton";
            this.CrimeTabButton.Size = new System.Drawing.Size(294, 82);
            this.CrimeTabButton.TabIndex = 7;
            this.CrimeTabButton.Text = "CRIME";
            this.CrimeTabButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CrimeTabButton.UseVisualStyleBackColor = false;
            this.CrimeTabButton.Click += new System.EventHandler(this.CrimeTabButton_Click);
            // 
            // JailTabButton
            // 
            this.JailTabButton.BackColor = System.Drawing.Color.Transparent;
            this.JailTabButton.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_2;
            this.JailTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.JailTabButton.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JailTabButton.ForeColor = System.Drawing.Color.White;
            this.JailTabButton.Image = global::CDMS.Properties.Resources.jail_6_;
            this.JailTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.JailTabButton.Location = new System.Drawing.Point(3, 232);
            this.JailTabButton.Name = "JailTabButton";
            this.JailTabButton.Size = new System.Drawing.Size(294, 79);
            this.JailTabButton.TabIndex = 6;
            this.JailTabButton.Text = "JAIL";
            this.JailTabButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.JailTabButton.UseVisualStyleBackColor = false;
            this.JailTabButton.Click += new System.EventHandler(this.JailTabButton_Click);
            // 
            // AboutTabButton
            // 
            this.AboutTabButton.BackColor = System.Drawing.Color.Transparent;
            this.AboutTabButton.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_2;
            this.AboutTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AboutTabButton.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AboutTabButton.ForeColor = System.Drawing.Color.White;
            this.AboutTabButton.Image = global::CDMS.Properties.Resources.ADMIN_LOGIN;
            this.AboutTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AboutTabButton.Location = new System.Drawing.Point(6, 409);
            this.AboutTabButton.Name = "AboutTabButton";
            this.AboutTabButton.Size = new System.Drawing.Size(288, 69);
            this.AboutTabButton.TabIndex = 5;
            this.AboutTabButton.Text = "ABOUT";
            this.AboutTabButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AboutTabButton.UseVisualStyleBackColor = false;
            this.AboutTabButton.Click += new System.EventHandler(this.AboutTabButton_Click);
            // 
            // JudgeTabButton
            // 
            this.JudgeTabButton.BackColor = System.Drawing.Color.Transparent;
            this.JudgeTabButton.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_2;
            this.JudgeTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.JudgeTabButton.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JudgeTabButton.ForeColor = System.Drawing.Color.White;
            this.JudgeTabButton.Image = global::CDMS.Properties.Resources.Judge_3_;
            this.JudgeTabButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.JudgeTabButton.Location = new System.Drawing.Point(3, 317);
            this.JudgeTabButton.Name = "JudgeTabButton";
            this.JudgeTabButton.Size = new System.Drawing.Size(291, 86);
            this.JudgeTabButton.TabIndex = 3;
            this.JudgeTabButton.Text = "JUDGE";
            this.JudgeTabButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.JudgeTabButton.UseVisualStyleBackColor = false;
            this.JudgeTabButton.Click += new System.EventHandler(this.JudgeTabButton_Click);
            // 
            // SlidingPannel_ToggelButton
            // 
            this.SlidingPannel_ToggelButton.BackColor = System.Drawing.Color.Transparent;
            this.SlidingPannel_ToggelButton.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_21;
            this.SlidingPannel_ToggelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SlidingPannel_ToggelButton.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SlidingPannel_ToggelButton.Image = global::CDMS.Properties.Resources.LEFT_Arrows_20_;
            this.SlidingPannel_ToggelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SlidingPannel_ToggelButton.Location = new System.Drawing.Point(0, 0);
            this.SlidingPannel_ToggelButton.Name = "SlidingPannel_ToggelButton";
            this.SlidingPannel_ToggelButton.Size = new System.Drawing.Size(300, 66);
            this.SlidingPannel_ToggelButton.TabIndex = 2;
            this.SlidingPannel_ToggelButton.UseVisualStyleBackColor = false;
            this.SlidingPannel_ToggelButton.Click += new System.EventHandler(this.SlidingPannel_ToggelButton_Click);
            // 
            // TitleBarPannel
            // 
            this.TitleBarPannel.BackColor = System.Drawing.Color.Gainsboro;
            this.TitleBarPannel.BackgroundImage = global::CDMS.Properties.Resources.APP_BODY_IMG_2;
            this.TitleBarPannel.Controls.Add(this.LogOffButton);
            this.TitleBarPannel.Controls.Add(this.MinimizeButton);
            this.TitleBarPannel.Controls.Add(this.closeButton);
            this.TitleBarPannel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TitleBarPannel.Location = new System.Drawing.Point(0, 0);
            this.TitleBarPannel.Name = "TitleBarPannel";
            this.TitleBarPannel.Size = new System.Drawing.Size(1244, 55);
            this.TitleBarPannel.TabIndex = 0;
            // 
            // LogOffButton
            // 
            this.LogOffButton.BackColor = System.Drawing.Color.Transparent;
            this.LogOffButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LogOffButton.BackgroundImage")));
            this.LogOffButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.LogOffButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogOffButton.ForeColor = System.Drawing.SystemColors.Menu;
            this.LogOffButton.Location = new System.Drawing.Point(1080, 3);
            this.LogOffButton.Name = "LogOffButton";
            this.LogOffButton.Size = new System.Drawing.Size(47, 49);
            this.LogOffButton.TabIndex = 3;
            this.LogOffButton.UseVisualStyleBackColor = false;
            this.LogOffButton.Click += new System.EventHandler(this.LogOffButton_Click);
            // 
            // MinimizeButton
            // 
            this.MinimizeButton.BackColor = System.Drawing.Color.Transparent;
            this.MinimizeButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MinimizeButton.BackgroundImage")));
            this.MinimizeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MinimizeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinimizeButton.ForeColor = System.Drawing.SystemColors.Menu;
            this.MinimizeButton.Location = new System.Drawing.Point(1133, 3);
            this.MinimizeButton.Name = "MinimizeButton";
            this.MinimizeButton.Size = new System.Drawing.Size(47, 49);
            this.MinimizeButton.TabIndex = 2;
            this.MinimizeButton.UseVisualStyleBackColor = false;
            this.MinimizeButton.Click += new System.EventHandler(this.MinimizeButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.BackColor = System.Drawing.Color.Transparent;
            this.closeButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("closeButton.BackgroundImage")));
            this.closeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.closeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.closeButton.ForeColor = System.Drawing.SystemColors.Menu;
            this.closeButton.Location = new System.Drawing.Point(1186, 3);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(47, 49);
            this.closeButton.TabIndex = 1;
            this.closeButton.UseVisualStyleBackColor = false;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // AppBody
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1244, 771);
            this.Controls.Add(this.ContentPannel);
            this.Controls.Add(this.SlidingPannel);
            this.Controls.Add(this.TitleBarPannel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AppBody";
            this.Text = "AppBody";
            this.Load += new System.EventHandler(this.AppBody_Load);
            this.SlidingPannel.ResumeLayout(false);
            this.TitleBarPannel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer Log_in_Timer;
        private System.Windows.Forms.Panel TitleBarPannel;
        private System.Windows.Forms.Button LogOffButton;
        private System.Windows.Forms.Button MinimizeButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Panel SlidingPannel;
        private System.Windows.Forms.Timer SlidingPannel_Timer;
        private System.Windows.Forms.Button CriminalTabButton;
        private System.Windows.Forms.Button CrimeTabButton;
        private System.Windows.Forms.Button JailTabButton;
        private System.Windows.Forms.Button AboutTabButton;
        private System.Windows.Forms.Button JudgeTabButton;
        private System.Windows.Forms.Button SlidingPannel_ToggelButton;
        private System.Windows.Forms.Panel ContentPannel;
    }
}